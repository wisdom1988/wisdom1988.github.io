// 定义一个接口,约束state的数据类型
export interface Todo {
  id: number,
  title: string,
  isCompleted: boolean
}
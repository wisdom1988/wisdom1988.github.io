(function () {
    function sayHi(str) {
        return '啊捏哈谁有' + str;
    }
    var text = '小甜甜';
    console.log(sayHi(text));
})();

(() => {
  function sayHi(str) {
    return '啊捏哈谁有' + str
  }
  let text = '小甜甜'
  console.log(sayHi(text))
})()
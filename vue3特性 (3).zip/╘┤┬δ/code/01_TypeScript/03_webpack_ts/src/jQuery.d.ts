// 定义操作
// declare var jQuery: (selector: string) => any
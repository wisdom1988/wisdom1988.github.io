// import './01_基础类型'
// import './01_接口'
// import './02_函数类型'
import './03_类类型'

document.write('哈哈,我又变帅了!!!')
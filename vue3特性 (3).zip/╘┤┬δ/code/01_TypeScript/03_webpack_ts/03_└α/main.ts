// import './01_基础类型'
// import './01_接口'
// import './02_函数类型'
// import './03_类类型'
// import './01_类'
// import './02_继承'
// import './03_多态'
// import './04_修饰符'
// import './05_readonly修饰符'
// import './06_存取器'
// import './07_静态成员'
import './08_抽象类'

document.write('哈哈,我又变帅了!!!')
<template>
  <h2 style="color: red;">你好！{{ x }}</h2>
</template>

<script setup lang="ts">
  
</script>
